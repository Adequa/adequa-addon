/* global Adequa */
"use strict";

Adequa.actions = {
    init: {},
    cookie: {},
    interface: {},
    navigation: {},
    page: {},
    request: {}
};

