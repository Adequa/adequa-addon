/* global Adequa */
"use strict";

Adequa.actions.init.start = function () {
    fetchCurrent(function () {
        if (Adequa.current.firstInstall !== false) {
            firstInstall();
        } else {
            if (!Adequa.current.addonToken) {
                Adequa.request.post(Adequa.uri + `api/addon/create`, {}).then((data) => {
                    Adequa.storage.setCurrent({addonToken: JSON.parse(data.response)});
                }).catch(console.warn);
            }
        }

        if(!Adequa.current.consent)
            Adequa.current.consent = {settings: []};

        Adequa.actions.resources.fetchAll();

        setTimer();
    });
};

const firstInstall = function () {
    Adequa.storage.setCurrent({
        installDate: Date.now(),
        nbMaxAdsPerDay: 25,
        server: {
            installDate: Date.now(),
            browser: Adequa.API.firefox ? 'firefox' : 'chrome'
        }
    });
    Adequa.request.post(Adequa.uri + `api/addon/create`, {}).then((data) => {
        Adequa.storage.setCurrent({addonToken: JSON.parse(data.response)});
    }).catch(console.warn);
    Adequa.actions.cookie.getProspectCookie(function (prospect) {
        if (!prospect) {
            return;
            // Adequa.storage.setCurrent({postInstallOpened: true})
            // return Adequa.API.tabs.open({url: Adequa.API.runtime.getURL('/adequa/post-installation.html')});
        }

        const checkTabs = function (tabs) {
            for (let tab of tabs) {
                if (tab.url.indexOf(prospect.domain) !== -1) {
                    updateTab(tab);
                    reloadTab(tab.id);
                    let data = Object.assign({}, Adequa.current.server);
                    data.new = {
                        converted_from: prospect.domain
                    };
                    Adequa.storage.setCurrent({convertedFrom: prospect.domain});
                }
            }

        };

        const updateTab = function (tab) {
            Adequa.API.tabs.update(tab.id, {active: true});
        };

        const reloadTab = function (tabId) {
            Adequa.API.tabs.reload(tabId);
        };
        Adequa.API.tabs.query({}, checkTabs)
    });
    Adequa.storage.setCurrent({firstInstall: false});
};

const fetchCurrent = function (callback) {
    Adequa.API.storage.get('current', function (data) {
        Adequa.current = data.current || {tabs: {}, versions: {}};
        callback();
    });
};

const setTimer = function () {
    setInterval(Adequa.actions.resources.fetchAll, 1000 * 60 * 30);
};

const onCookieChanged = function (changeInfo) {
    Adequa.messaging.send({
        what: 'cookieChanged',
        changeInfo
    });
};

Adequa.API.cookies.onChanged.addListener(onCookieChanged);

Adequa.messaging.send({what: "adequaStart"});
