Adequa.API.storage = chrome.storage.local;
