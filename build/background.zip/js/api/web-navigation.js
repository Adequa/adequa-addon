Adequa.API.webNavigation = chrome.webNavigation;
