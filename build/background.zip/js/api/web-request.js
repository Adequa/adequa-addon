Adequa.API.webRequest = chrome.webRequest;
