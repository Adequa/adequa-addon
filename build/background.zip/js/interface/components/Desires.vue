<template>
    <div>
        Bientôt vous pourrez choisir ici vos envies
    </div>
</template>

<script>
    export default {
        name: "Desires"
    }
</script>

<style scoped>
    div {
        margin-top: -40px;
        flex: 1;
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
    }
</style>
