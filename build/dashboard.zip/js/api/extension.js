Adequa.API.extension = chrome.extension;
