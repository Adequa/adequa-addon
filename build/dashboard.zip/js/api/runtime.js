Adequa.API.runtime = chrome.runtime;
