Adequa.API.cookies = chrome.cookies;
