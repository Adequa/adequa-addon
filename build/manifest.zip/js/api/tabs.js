Adequa.API.tabs = chrome.tabs;
